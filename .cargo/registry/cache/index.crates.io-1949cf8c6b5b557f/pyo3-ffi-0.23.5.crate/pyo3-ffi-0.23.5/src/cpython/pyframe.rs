#[cfg(all(Py_3_11, not(PyPy)))]
opaque_struct!(_PyInterpreterFrame);
